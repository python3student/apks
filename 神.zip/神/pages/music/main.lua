require "import"
import "com.androlua.*"
import "android.widget.*"
import "android.view.*"
import "android.app.DownloadManager"
import "android.content.*"
import "android.os.*"
import "android.net.*"
import "androidx.appcompat.widget.PopupMenu"
import "androidx.recyclerview.widget.RecyclerView"
import "androidx.recyclerview.widget.LinearLayoutManager"
import "com.google.android.material.card.MaterialCardView"
import "com.google.android.material.dialog.MaterialAlertDialogBuilder"
import "com.google.android.material.snackbar.Snackbar"
import "net.fusionapp.core.ui.adapter.BasePagerAdapter"
import "net.fusionapp.core.util.FusionUtil"
import "cjson"
--Custom file
import "layout"
import "item"

function setContentView(view)
  local uiManager=this.UiManager
  local viewPager=uiManager.viewPager
  local list=ArrayList()
  list.add(view)
  viewPager.setAdapter(BasePagerAdapter(list))
end

function make_Snackbar(text, btn, fun)
  if not activity.isFinishing() then
    if btn==nil then
      btn="确定"
    end
    if fun==nil then
      fun=function(v) end
    end
    local anchor=activity.findViewById(android.R.id.content)
    Snackbar.make(anchor, text, Snackbar.LENGTH_SHORT).setAction(btn, View.OnClickListener{
      onClick=fun
    }).show();
  end
end

function onDrawerListItemClick(data, recyclerView, listIndex, itemIndex)
  local listData = data.get(listIndex);
  local itemData = listData.get(itemIndex);
  local itemTitle = itemData.getTitle();
  switch(itemTitle) do
   case "夜间模式"
    if itemData.isChecked() then
      switchTheme(itemData, false, "Default_Light.json")
     else
      switchTheme(itemData, true, "Dark.json")
    end
   case "关于"
    MaterialAlertDialogBuilder(activity)
    .setTitle("关于")
    .setMessage("一个下载音乐的小工具。\n\n默认下载到/sdcard/Music/目录下，此处是公共目录，软件不会创建多余的无用文件夹")
    .setPositiveButton("确定",nil)
    .show()
   case "退出"
    activity.finish()
  end
  this.UiManager.toggleDrawer()
end

function onFloatingActionButtonClick()
  if edit.text=="" then
    make_Snackbar("请输入")
   else
    make_Snackbar("搜索中..")
    搜索歌曲()
  end
end

function 搜索歌曲()
  local sourceType={网易云="netease",咪咕="migu",酷狗="kugou",QQ="qq"}
  Http.post("http://47.112.23.238/Music/getMusicList",
  "musicName="..edit.text.."&type="..sourceType[sousuo.text].."&number=50",function(a,b,c,d)
    if a==200 then
      json=cjson.decode(b)
      data=json.data
      songs={}
      songList.Adapter.clear()
      if(tostring(data)~="userdata: 0x0")then
        for i=1,#data do
          table.insert(songs,{
            title=data[i].title,
            author=data[i].author,
            pic=data[i].pic,
            url=data[i].url,})
        end
        songList.Adapter.addAll(songs)
       else
        make_Snackbar("结果为空")
      end
     else
      make_Snackbar("网络不可用")
    end
  end)
end

function recreate()
  activity.finish();
  activity.startFusionActivity(activity.getLoader().getPageName());
  activity.overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
end

function switchTheme(listItemData, isNightMode, newThemeName)
  listItemData.setChecked(isNightMode)
  activity.getLoader().updatePageConfig()
  FusionUtil.changeTheme(activity.getLoader().getProjectDir().getAbsolutePath(), newThemeName)
  FusionUtil.setNightMode(isNightMode)
  recreate()
end

--main
setContentView(loadlayout(layout))
songs={}

songList.layoutManager=LinearLayoutManager(activity)
songList.Adapter=LuaRecyclerAdapter(activity,songs,item)
songList.Adapter.clickViewId="itemCard"
songList.Adapter.onItemClick=function(a,p,c,d)--列表单击
  songItemName=songs[d+1].title
  songItemSinger=songs[d+1].author
  songItemLink=songs[d+1].url
  MaterialAlertDialogBuilder(activity)
  .setTitle("提示")
  .setMessage("歌曲:"..songItemName.."\n歌手:"..songItemSinger.."\n链接:"..songItemLink)
  .setPositiveButton("取消",nil)
  .setNeutralButton("下载",{onClick=function(v)
      downloadManager=activity.getSystemService(Context.DOWNLOAD_SERVICE);
      url=Uri.parse(songItemLink);
      request=DownloadManager.Request(url);
      request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE|DownloadManager.Request.NETWORK_WIFI);
      request.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC,songItemName..".mp3");
      request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
      downloadManager.enqueue(request);
      make_Snackbar(songItemName.." 加入下载")
    end
  })
  .show()
  print("下载功能还在开发中，权限不够，不一定能下载\n长按复制下载链接")
  return true
end
songList.Adapter.onItemLongClick=function(adapter,itemView,view,pos)
  pop=PopupMenu(activity,view)
  menu=pop.Menu
  menu.add("复制下载链接").onMenuItemClick=function(a)
    activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(songs[pos+1].url)
    make_Snackbar("已复制："..songs[pos+1].url)
  end
  pop.show()
end
