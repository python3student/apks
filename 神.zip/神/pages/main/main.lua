--
-- @author 寒歌
-- @description Main是应用的主模块，其中注册了应用运行中UI事件的回调、Activity生命周期的回调等
-- 你也可以在此编写启动事件代码，或控制应用运行逻辑、自定义应用UI等等。
-- @other 本模版已为你编写好基础事件，建议在阅读注释并理解相关参数意义后再进行扩展编写
--

require "import"
import "android.content.Context"
import "android.net.ConnectivityManager"

-- @param data 侧滑栏列表的全部数据
-- @param recyclerView 侧滑栏列表控件
-- @param listIndex 点击的列表索引（点击的是第几个列表）
-- @param clickIndex 点击的项目索引（点击的第几个项目）
function onDrawerListItemClick(data, recyclerView, listIndex, itemIndex)
  --侧滑栏列表的数据是二维结构，所以需要先获取到点击项目所在列表的数据
  local listData = data.get(listIndex);
  --获取到所在列表的数据后获取点击项目的数据
  local itemData = listData.get(itemIndex);
  --最后获取到点击的项目的标题
  local itemTitle = itemData.getTitle();

  --TODO：
  switch(itemTitle) do
   case "夜间模式"
    if itemData.isChecked() then
      switchTheme(itemData, false, "Default_Light.json")
     else
      switchTheme(itemData, true, "Dark.json")
    end
   case "学习资料"
    activity.startFusionActivity("study")
   case "电脑版"
    activity.startFusionActivity("c")
   case "CCTV"
    activity.startFusionActivity("CCTV")
   case "退出"
    activity.finish()
   case "音乐"
    activity.startFusionActivity("music")
   case "小店"
    activity.startFusionActivity("shop")
   case "python教程"
    对话框()
    .设置标题("提示")
    .设置消息("这里最好注册一个账号\n以方便学习")
    .设置积极按钮("确定",function()
    end)
    .显示()
    --中文对话框编写者：难忘的旋律
    this.UiManager.getCurrentFragment().getWebView().loadUrl("http://520mg.com/it/#/main/2")
   case "web开发学习"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.mozilla.org/zh-CN/docs/Learn")
   case "安卓开发指南"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.android.google.cn/training/basics/firstapp")
   case "CSS学习"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.mozilla.org/zh-CN/docs/Glossary/CSS")
   case "HTML学习"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.mozilla.org/zh-CN/docs/Glossary/HTML")
   case "js学习"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.mozilla.org/zh-CN/docs/Glossary/JavaScript")
   case "web前端开发学习"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://developer.mozilla.org/zh-CN/docs/learn/Front-end_web_developer")
   case "纪妖"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("http://www.cbaigui.com")
   case "没用"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("http://theuselessweb.com")
   case "历史"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("http://www.allhistory.com")
   case "games"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("http://kevin.games")
   case "主页"
    this.UiManager.getCurrentFragment().getWebView().loadUrl("https://python3student.github.io/")
   case "关于" --对话框使用
    local MaterialAlertDialogBuilder = luajava.bindClass "com.google.android.material.dialog.MaterialAlertDialogBuilder"
    MaterialAlertDialogBuilder(activity)
    .setTitle("关于神奇")
    .setMessage("尝试制作的一个简单APP\n感谢使用ヾ^_^♪")
    .setPositiveButton("OK",nil)--function()print("")end)
    --.setNegativeButton("取消",nil)
    .show()
   default print(itemTitle)
  end
  this.UiManager.toggleDrawer()
end

-- @param keyword 搜索栏输入的文本
-- @description 顶栏搜索功能回调事件
function onSearchEvent(keyword)
  --TODO：
  print("Search keyword:"..keyword)
end

-- @param title 点击的菜单标题
-- @description 顶栏菜单项目点击回调事件
function onMenuItemClick(title)
  switch(title) do
   case "刷新"
    this.UiManager.getCurrentFragment().getWebView().reload()
   case "复制"
    --获取当前页面的URL
    local url=this.UiManager.getCurrentFragment().webView.getUrl()
    对话框()
    .设置标题("网页链接")
    .设置消息("当前网页的链接为:\n"..url)
    .设置积极按钮("复制",function()
      复制文本(url)
    end)
    .设置消极按钮("取消")
    .显示()
    --中文对话框编写者：难忘的旋律
   default print(title.."还在开发中")
  end
end


--悬浮按钮点击事件
function onFloatingActionButtonClick(v)
  print("floating action button click")
end

function switchTheme(listItemData, isNightMode, newThemeName)
  listItemData.setChecked(isNightMode)
  activity.getLoader().updatePageConfig()
  FusionUtil.changeTheme(activity.getLoader().getProjectDir().getAbsolutePath(), newThemeName)
  FusionUtil.setNightMode(isNightMode)
  recreate()
end


--程序启动时会执行的事件
--程序启动事件
--网络检测
manager = activity.getSystemService(Context.CONNECTIVITY_SERVICE);
gprs = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();
if tostring(gprs)== "CONNECTED" then
  --连接
  print("正在使用流量")
  --上面括号内容可任意修改或者删除print打印事件
 else
  connManager = activity.getSystemService(Context.CONNECTIVITY_SERVICE)
  mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
  if tostring(mWifi):find("none") then
    --未连接
    print("网络未连接")
    --上面括号内容可任意修改(不建议删除)
   else
    --连接
    print("正在使用WIFI网络")
    --上面括号内容可任意修改或者删除print打印事件
  end
end
--将所有的代码放入程序启动事件里面.

URL="https://github.com/python3student/apks/blob/main/README.md"--你的远端数据的地址
Http.get(URL,function(code,cont)
  if code ~= 200 then --如果服务器返回数据异常，`
    print("检测更新服务器失联")
  end
  --cont就是服务器返回的数据，之后所有的代码都写在这里
  --local用来声明局部变量，及这里的所以东西对你的其他代码的都没有任何影响。
  local PackageName=this.getPackageName()--包名
  local PackInfo=this.getPackageManager().getPackageInfo(PackageName,64)--包信息
  local 本地版本=tonumber(PackInfo.versionCode)--版本号，这是我们要用的
  --由于之后需要进行判断，因此此处使用tonumber()方法转换为数字
  local 远端版本=cont:match("【版本】(.-)【版本】")
  local 地址=cont:match("【下载】(.-)【下载】")
  local 下载地址="https://"..地址
  if tonumber(远端版本)>本地版本 then
    --提示检测更新
    对话框()
    .设置标题("检查更新")
    .设置消息("发现有新版本\n点击更新进行下载更新")
    .设置积极按钮("更新",function()
      import "android.content.Intent"
      import "android.net.Uri"
      local viewIntent = Intent("android.intent.action.VIEW",Uri.parse(下载地址))
      activity.startActivity(viewIntent)
      --顺带提醒下用户，免得他们一脸懵逼
      print("请在打开的页面中下载更新并安装~")
      --当然如果你想强制更新的话，可以把下面这一行加上
      activity.finish() --结束程序
    end)
    .设置消极按钮("暂不更新")
    .显示()
    --中文对话框编写者：难忘的旋律
  end
end)
